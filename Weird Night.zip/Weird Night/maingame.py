import time

def sprint(a,b):
    for i in b:
        time.sleep(a)
        # I wanted to write a different code then we wrote in the class so i used flush=True
        print(i, end='', flush=True)
    print('')
        
inventory = []

curloc = []

rooms = {
    "room": {
        "east": "soft wall",
        "west": "hallway",
        "north": "nothing",
        "south": "nothing"
    },
    "hallway": {
        "north": "way",
        "east": "room",
        "west":"kitchen",
        "south": "bathroom"
    },
    "kitchen": {
        "east": "hallway",
        "west": "knife",
        "north": "nothing",
        "south": "nothing"

    }
}

sprint(0.05,'-------------------------------')
sprint(0.08,'          WEIRD NIGHT          ')
sprint(0.05,'-------------------------------')
time.sleep(1)
print("INFO: Select your choices by pressing numbers. If you want to restart from the start, just type 'reset' at a choice section.")
time.sleep(1)
print('Press Enter to Start')
input('>')
while True:
    goodend=0
    reset=False
    curloc=rooms["room"]
    sprint(0.03,"I woke up in a pitch black room.")
    input('>')
    sprint(0.03,"The room has no light source, I barely see my own hands.")
    input('>')
    sprint(0.03,"What's going on? Where am I?")
    input('>')
    sprint(0.03,"I waved my hands around, trying to touch something.")
    input('>')
    sprint(0.03,"And on a table, as if it had been placed there intentionally, I found a flashlight.")
    input('>')
    sprint(0.03,"I could see the room clearly when I turned on the light.")
    input('>')
    sprint(0.03,"It's weird there is no windows, just a bed and a table")
    input('>')
    sprint(0.03,"What should I do now?")
    print("--You can look arund by writing directions (north, south, east, west)--")
    while True:
        choice1 = input('>')    
        if choice1 == "east":
            sprint(0.03,"I turned my head to east side of the room.")
            input('>')
            sprint(0.03,"And immediately discovered something.")
            input('>')
            sprint(0.03,"In the wall, there is a small section feels soft unlike the others.")
            input('>')
            sprint(0.03,"Maybe I can dig it up if i find something sharp.")
            input('>')
            sprint(0.2,"GRROOWWR...")
            time.sleep(1)
            sprint(0.03,"What was that sound?")
            input('>')
            sprint(0.03,"It sounded like some sort of monster sound effect from a video game.")
            input('>')
            sprint(0.03,"And it came from west i think")
            input('>')
            sprint(0.03,"Maybe I should find out where is the sound coming from.")
            input('>')
            sprint(0.03,"But wait...")
            input('>')
            sprint(0.03,"What if this is not just a sound effect but a real monster?")
            input('>')
            sprint(0.03,"I'm experiencing a dream-like situation so far and everything seems possible.")
            input('>')
            sprint(0.03,"What should I do now?")
            print("--You can look arund by writing directions (north, south, east, west)--")
            while True:
                choice2 = input('>')
                if choice2 == "west":
                    sprint(0.03,"It's impossible that monsters can exist right? So there is no need to worry.")
                    input('>')
                    sprint(0.03,"I think the sound is coming from the kitchen. Here we go.")
                    input('>')
                    sprint(0.2,"GRROOWWR...")
                    time.sleep(1)
                    sprint(0.03,"As I'm getting closer, the sound gets louder.")
                    input('>')
                    sprint(0.03,"And finally i came to the kitchen. The moment of truth.")
                    input('>')
                    sprint(0.2,"GRROOWWR...")
                    time.sleep(1)
                    sprint(0.03,"And yes, just as I thought.")
                    input('>')
                    sprint(0.03,"This is just a playback device.")
                    input('>')
                    sprint(0.03,"Also i realized i can find a knife in here and cut that soft section of the wall.")
                    input('>')
                    sprint(0.03,"I opened a drawer and took a knife.")
                    input('>')
                    inventory += "knife"
                    sprint(0.03,"And then got back to the room i wake.")
                    input('>')
                    sprint(0.03,"Let's start digging.")
                    input('>')
                    sprint(0.03,"...")
                    input('>')
                    sprint(0.03,"After thirty minutes of hardwork, i created a hole in the wall.")
                    input('>')
                    sprint(0.03,"I climbed out through the hole")
                    input('>')
                    sprint(0.03,"And now I'm in a very big, white room.")
                    input('>')
                    sprint(0.03,"The situation keeps getting weirder")
                    input('>')
                    sprint(0.05,"CONGRATS HUMAN, NOW YOU PROVED THAT YOU ARE WORTHY")
                    input('>')
                    sprint(0.03,"Who's talking?")
                    input('>')
                    sprint(0.05,"THIS WAS A LITTLE CHALLANGE TO PROVE YOURSELF")
                    input('>')
                    sprint(0.05,"NOW YOU CAN GO BACK TO YOUR NORMAL LIFE")
                    input('>')
                    sprint(0.03,"Hey excuse me but what exactly was this challange for? Also can you show yourself?")
                    input('>')
                    sprint(0.05,"GOODBYE")
                    input('>')
                    sprint(0.03, "Hey wait!")
                    time.sleep(0.5)
                    sprint(0.03,"And with a snap sound, I lost my mind.")
                    sprint(1,"...")
                    time.sleep(2)
                    input('>')
                    time.sleep(2)
                    sprint(0.03,"*yawn*")
                    input('>')
                    sprint(0.03,"Ahh... I should wake up now or I'll be late to school")
                    input('>')
                    sprint(0.03,"Wait a sec...")
                    input('>')
                    sprint(0.03,"Today is Saturday!")
                    input('>')
                    sprint(0.03,"I can sleep for a 3 more hours then")
                    input('>')
                    sprint(0.03,"Now that's what i call 'living my life to fullest'")
                    input('>')
                    goodend = 1
                    reset = True
                    break


                elif choice2 == "north":
                    sprint(0.03,"There is nothing at there")
                    continue
                elif choice2 == "south":
                    sprint(0.03,"There is nothing at there")
                    continue
                elif choice2 == "east":
                    sprint(0.03,"Let's try to avoid from unknown")
                    input('>')
                    sprint(0.03,"I got out of the room and searched the house for some more information.")
                    input('>')
                    sprint(0.03,"The hallway is narrow but long.")
                    input('>')
                    sprint(0.03,"I wonder how this place looks from outside.")
                    input('>')
                    sprint(0.03,"I walked through the hallway for finding the exit door but this hallway is just too long.")
                    input('>')
                    sprint(0.03,"...")
                    input('>')
                    sprint(0.03,"After about ten minutes, I'm still going through the hallway.")
                    input('>')
                    sprint(0.03,"have i gone crazy?")
                    input('>')
                    sprint(0.03,"Should i keep going until the end or check the other rooms?")
                    time.sleep(1)
                    sprint(0.01,"1-[Keep going until the end]")
                    sprint(0.01,"2-[Check the bathroom]")
                    while True:
                        choice3 = input('>')    
                        if choice3 == "1":
                            sprint(0.03,"It's imposibble for this hallway to be endless.")
                            input('>')
                            sprint(0.03,"now i started to walk and cannot stop")
                            input('>')
                            sprint(0.03,"...")
                            sprint(0.03,"I can't beleive this. Another ten minutes passed and I'm still walking")
                            input('>')
                            sprint(0.03,"I need to wake up if this is a dream")
                            input('>')
                            sprint(0.07,"I'm afraid you can't")
                            time.sleep(1)
                            sprint(0.03,"What? Who is talking?")
                            input('>')
                            sprint(0.03,"And with a snap sound, I lost my mind.")
                            input('>')
                            sprint(1,"...")
                            time.sleep(2)
                            reset = True
                            break
                                
                        elif choice3 == "2":
                            sprint(0.03,"I went to the bathroom.")
                            input('>')
                            sprint(0.03,"But couldn't find anything useful")
                            input('>')
                            sprint(0.03,"And then i went to bedroom")
                            input('>')
                            sprint(0.03,"But again, nothing useful")
                            input('>')
                            sprint(0.03,"What am i missing?")
                            input('>')
                            sprint(0.07,"Your time is up.")
                            input('>')
                            sprint(0.03,"What? Who is talking?")
                            input('>')
                            sprint(0.03,"And with a snap sound, I lost my mind.")
                            sprint(1,"...")
                            time.sleep(2)
                            reset = True
                            break


                        elif choice3 == "reset":
                            reset = True
                            break
                        else:
                            print("Wrong input, try again")
                elif choice2 == "reset":
                    reset = True
                    break
                else:
                    print("Wrong input, try again")
                if reset:
                    break
        elif choice1 == "west":
            sprint(0.03,"I got out of the room and searched the house for some more information.")
            input('>')
            sprint(0.03,"The hallway is narrow but long.")
            input('>')
            sprint(0.03,"I wonder how this place looks from outside.")
            input('>')
            sprint(0.03,"I walked through the hallway for finding the exit door but this hallway is just too long.")
            input('>')
            sprint(0.03,"...")
            input('>')
            sprint(0.03,"After about ten minutes, I'm still going through the hallway.")
            input('>')
            sprint(0.03,"have i gone crazy?")
            input('>')
            sprint(0.03,"Should i keep going until the end or check the other rooms?")
            time.sleep(1)
            sprint(0.01,"1-[Keep going until the end]")
            sprint(0.01,"2-[Check the bathroom]")
            while True:
                choice4 = input('>')    
                if choice4 == "1":
                    sprint(0.03,"It's imposibble for this hallway to be endless.")
                    input('>')
                    sprint(0.03,"now i started to walk and cannot stop")
                    input('>')
                    sprint(0.03,"...")
                    input('>')
                    sprint(0.03,"I can't beleive this. Another ten minutes passed and I'm still walking")
                    input('>')
                    sprint(0.03,"I need to wake up if this is a dream")
                    input('>')
                    sprint(0.07,"I'm afraid you can't")
                    time.sleep(1)
                    sprint(0.03,"What? Who is talking?")
                    sprint(0.03,"And with a snap sound, I lost my mind.")
                    input('>')
                    sprint(1,"...")
                    time.sleep(2)
                    reset = True
                    break
                           
                elif choice4 == "2":
                    sprint(0.03,"I went to the bathroom.")
                    input('>')
                    sprint(0.03,"But couldn't find anything useful")
                    input('>')
                    sprint(0.03,"And then i went to bedroom")
                    input('>')
                    sprint(0.03,"But again, nothing useful")
                    input('>')
                    sprint(0.03,"What am i missing?")
                    input('>')
                    sprint(0.07,"Your time is up.")
                    input('>')
                    sprint(0.03,"What? Who is talking?")
                    input('>')
                    sprint(0.03,"And with a snap sound, I lost my mind.")
                    sprint(1,"...")
                    time.sleep(2)
                    reset = True
                    break
                    
                elif choice4 == "reset":
                    reset = True
                    break
                else:
                    print("Wrong input, try again")
        elif choice1 == "north":
            sprint(0.03,"There is nothing at there")
            continue
        elif choice1 == "south":
            sprint(0.03,"There is nothing at there")
            continue
        
        elif choice1 == "reset":
            reset = True
            break
        else:
            print("Wrong input, try again")
        if reset:
            break
    if reset and goodend == 0:
        continue
    else:
        sprint(0.3,"T H E  E N D")
        break